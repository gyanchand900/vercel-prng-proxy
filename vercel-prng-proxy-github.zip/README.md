# 🧩 Vercel PRNG Proxy

A simple Node.js proxy API for Smart Predictor (Wingo result fetcher).

## 🚀 Usage
- Deploy this repository to [Vercel](https://vercel.com)
- It will expose `/api/result` endpoint that fetches data from:
  `https://wingo.oss-ap-southeast-7.aliyuncs.com/api/v1/result`

## 🔧 Local Development
```bash
npm install -g vercel
vercel dev
```

## 🌍 Deployment
Once deployed, you'll get a URL like:
```
https://vercel-prng-proxy-yourname.vercel.app/api/result
```
Use this in your Smart Predictor HTML:
```js
const API_URL = "https://vercel-prng-proxy-yourname.vercel.app/api/result";
```
