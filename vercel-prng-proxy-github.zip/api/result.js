// api/result.js
export default async function handler(req, res) {
  const TARGET_URL = "https://wingo.oss-ap-southeast-7.aliyuncs.com/api/v1/result";

  try {
    const response = await fetch(TARGET_URL, {
      headers: { "cache-control": "no-cache" },
    });

    if (!response.ok) {
      return res.status(response.status).json({ error: `Target error ${response.status}` });
    }

    const data = await response.json();

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET,OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");

    if (req.method === "OPTIONS") return res.status(200).end();

    res.status(200).json(data);
  } catch (err) {
    res.status(500).json({ error: "Proxy failed", details: err.message });
  }
}
